<!doctype html>
<html>
    <link rel="stylesheet" href="sign.css">
        <body>
            <div class="part">
                <form action="signInProcessing.php">
                    <br><br><br><br><br><br>
                    이메일<br><input type="email" name="email"><br><br>
                    비밀번호<br><input type="password" name="psw"><br><br>
                    <input type="submit" value="로그인">
                </form>
            </div>
        </body>
    </html>
