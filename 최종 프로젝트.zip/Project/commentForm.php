<form action="comment_create.php" method="post">

	<table>
		<tbody>

			<tr>
				<hr>
				<td><textarea name="Content" placeholder="댓글작성"></textarea></td>
			</tr>
		</tbody>
	</table>

		<input type="submit" value="입력">
</form>
