  <link rel="stylesheet" href="sign.css">
    <form action="deleteFriend.php" class="form-container" method="post">
        <label for="email"><b>친구이름</b></label>
        <input type="text" placeholder="Enter name" name="friend_email" required>
        <button type="submit">삭제</button>
    </form>
