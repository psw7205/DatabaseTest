<!DOCTYPE html>
<html>
    <link rel="stylesheet" href="sign.css">
        <body>
            <div class="part">
                <form action = "signUpSave.php" method="post">
                    <br><br><br><br><br><br>
                    이메일<br><input type="email" name="username"><br><br>
                    비밀번호<br><input type="password" name="userPassWord"><br><br>
                    <input type="submit" value="가입하기">
                </form>
            </div>
       </body>
    </html>
